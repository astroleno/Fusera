# Acreage Farming

Precision farming landing page with dark/light sections, hero video background, stats grid, logo marquee, and service cards.